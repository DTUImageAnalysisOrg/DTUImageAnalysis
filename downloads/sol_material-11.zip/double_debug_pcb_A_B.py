

from skimage.io import imread
from skimage.color import rgb2gray
from skimage.filters import gaussian
import matplotlib.pyplot as plt 
import numpy as np 


def shortest_path_left_right(im: np.array) -> np.array:     
    accumulator_image = np.zeros_like(im)
    backtracking_image = np.zeros_like(im).astype(int)
    accumulator_image[:, 0] = im[:, 0]
    for col in range(1, accumulator_image.shape[1]): #left to right, first row already initialized
            for row in range(accumulator_image.shape[0]):
                r_min = max(0, row - 1) #handle borders
                r_max = min(accumulator_image.shape[0] - 1, row + 1) #handle borders
                search_area = accumulator_image[r_min : r_max + 1, col - 1] # available rows: [row, row+1] or [row-1, row, row+1] or [row-1, row]
                min_idx_relative = np.argmin(search_area)
                best_row = r_min + min_idx_relative
                accumulator_image[row, col] = im[row, col] + accumulator_image[best_row, col-1]
                backtracking_image[row, col] = best_row
    return accumulator_image, backtracking_image 



def backtrace_path(A, T, end_point = None):
    if end_point is None: 
        row_tmp = np.argmin(A[:, -1])
        start_col = A.shape[1] - 1
    else:
        row_tmp = end_point[0]
        start_col = end_point[1]

    print(f"Found cost: {A[row_tmp,start_col]}")

    path_x, path_y = [], []
    for col in range(start_col, -1, -1):
        path_x.append(col)
        path_y.append(row_tmp)
        row_tmp = T[row_tmp, col]                            
    return path_x, path_y 


start_coords = [118,49]
end_coords = [102,449] #what we actually want


im = imread("data/pcb.jpeg",)
crop_bounds = [[1150,1400],[1350,1850]]
im_crop = im[crop_bounds[0][0]:crop_bounds[0][1],crop_bounds[1][0]:crop_bounds[1][1]]

start_coords = [118,49]
end_coords = [102,449] #what we actually want
plt.imshow(im_crop)
plt.scatter(start_coords[1],start_coords[0], color = "orange", alpha=0.4)
plt.scatter(end_coords[1],end_coords[0], color = "magenta", alpha = 0.4)
plt.show()

im_crop = rgb2gray(im_crop)
im_crop_r = 1.0-im_crop

im_crop_r[(im_crop_r<0.60) | (im_crop_r>0.71)] = 1.0 
im_crop_r[(im_crop_r>=0.60) & (im_crop_r<=0.71)] = 0.0 


h_, w_ = im_crop_r.shape
im_crop_r_start = im_crop_r[:,start_coords[1]:]
start_coords[1] = start_coords[1]-(w_-im_crop_r_start.shape[1])
end_coords[1] = end_coords[1]-(w_-im_crop_r_start.shape[1])


def shortest_path_left_right(im: np.array, start_point: list = None) -> np.array: 
    accumulator_image = np.zeros_like(im)
    backtracking_image = np.zeros_like(im).astype(int)
    """Add the following 5 lines"""

    if start_point:
            accumulator_image[:, 0] = np.inf # High cost -> enforce the path to go through start point 
            accumulator_image[start_point[0], 0] = im[start_point[0], 0] #keep intensity for start_point 
    else:
        accumulator_image[:, 0] = im[:, 0]
    for col in range(1, accumulator_image.shape[1]): #left to right, first row already initialized
            for row in range(accumulator_image.shape[0]):
                r_min = max(0, row - 1) #handle borders
                r_max = min(accumulator_image.shape[0] - 1, row + 1) #handle borders
                search_area = accumulator_image[r_min : r_max + 1, col - 1] # available rows: [row, row+1] or [row-1, row, row+1] or [row-1, row]
                min_idx_relative = np.argmin(search_area)
                best_row = r_min + min_idx_relative
                accumulator_image[row, col] = im[row, col] + accumulator_image[best_row, col-1]
                backtracking_image[row, col] = best_row
    return accumulator_image, backtracking_image 



def shortest_path_old(im: np.array, direction: str, start_point: list = None, end_point: list = None) -> np.array: 
    """Runs path tracing algorithm in positive direction, either horizontally or vertically

    Args:
        im (np.array): the input image (grayscale)
        direction (str): the direction to use. 

    Returns:
        np.array: the accumulator image 
    """
    horizontal = True if direction.lower()=="horizontal" else False 
    vertical = True if direction.lower()=="vertical" else False 
    

    accumulator_image = np.zeros_like(im)
    backtracking_image = np.zeros_like(im).astype(int)
    path_x = []
    path_y = []
    if vertical:
        accumulator_image[0,:] = im[0,:]

        for row in range(1, accumulator_image.shape[0]): 
            for col in range(accumulator_image.shape[1]):
                c_min = max(0, col-1)
                c_max = min(accumulator_image.shape[1]-1,col+1)
                search_area = accumulator_image[row-1,c_min:c_max+1]
                min_idx_relative = np.argmin(search_area)
                best_col = c_min+min_idx_relative
                accumulator_image[row,col] = im[row,col]+accumulator_image[row-1,best_col]
                backtracking_image[row,col] = best_col
        #backtracking 
        if end_point is None: 
            col_tmp = np.argmin(accumulator_image[-1, :])
            start_row = accumulator_image.shape[0] - 1
        
        else:
            start_row = end_point[0]
            col_tmp = end_point[1]
                
        # Trace back to row 0
        for row in range(start_row, -1, -1):
            path_x.append(col_tmp)
            path_y.append(row)
            print(row, col_tmp)
            col_tmp = backtracking_image[row, col_tmp]        

    elif horizontal: 
            if start_point:
                accumulator_image[:, 0] = np.inf # High cost
                accumulator_image[start_point[0], 0] = im[start_point[0], 0]
        
            else:
                accumulator_image[:, 0] = im[:, 0]
            for col in range(1, accumulator_image.shape[1]):
                    for row in range(accumulator_image.shape[0]):
                        #search radius
                        r_min = max(0, row - 1)
                        r_max = min(accumulator_image.shape[0] - 1, row + 1)
                        search_area = accumulator_image[r_min : r_max + 1, col - 1] # available rows: [row-1, row, row+1]
                        min_idx_relative = np.argmin(search_area)
                        best_row = r_min + min_idx_relative
                        accumulator_image[row, col] = im[row, col] + accumulator_image[best_row, col-1]
                        backtracking_image[row, col] = best_row
            # Backtracking
            if end_point is None: 
                row_tmp = np.argmin(accumulator_image[:, -1])
                start_col = accumulator_image.shape[1] - 1
            else:
                row_tmp = end_point[0]
                start_col = end_point[1]
                    
            # Trace back to column 0
            for col in range(start_col, -1, -1):
                path_x.append(col)
                path_y.append(row_tmp)
                row_tmp = backtracking_image[row_tmp, col]                        
    
    if end_point: 
         # Check if the endpoint is actually reachable

        total_cost = accumulator_image[end_coords[0], end_coords[1]]

        if total_cost == np.inf or total_cost>=1e-3:
            print("STATUS: OPEN CIRCUIT - No electrical connection found.")
            # You might want to return empty path lists here to signify failure
        else:
            print(f"STATUS: CONNECTED - Path found with cost {total_cost}")

    return accumulator_image, backtracking_image, path_x, path_y 






A, T = shortest_path_left_right(im_crop_r, start_point=start_coords)
x,y = backtrace_path(A,T,end_point=end_coords)
fig, ax = plt.subplots(1,2)
ax[0].matshow(A)
ax[0].plot(x,y,color="red")
    
x = [x_+(w_-im_crop_r_start.shape[1]) for x_ in x]
y = [y_+(h_-im_crop_r_start.shape[0]) for y_ in y]

ax[1].imshow(im_crop_r,cmap="gray")
ax[1].plot(x,y,color="red")
ax[1].scatter(start_coords[1]+w_-im_crop_r_start.shape[1],start_coords[0], color="orange", alpha=0.4)
ax[1].scatter(end_coords[1]+w_-im_crop_r_start.shape[1],end_coords[0], color = "magenta", alpha = 0.4)

plt.show()

print(A[end_coords[0],end_coords[1]])
print(A[end_coords[0],end_coords[1]]) #if this is larger than zero there is a defect present
plt.matshow(A,vmin=0.0,vmax=1) #the complete trace of electrical connectivity from point A




#electrical connectivity between two points 
im_crop_r_start[im_crop_r_start==1.0] = 1e6
#im_crop_r[(im_crop_r>=0.60) & (im_crop_r<=0.71)] = 0.0 
A, T, x, y = shortest_path_left_right(im_crop_r_start,"horizontal", start_point=start_coords, end_point=end_coords)
#plot_results(im_crop_r_start,A,x,y)
fig, ax = plt.subplots(1,2)
ax[0].matshow(A)
ax[0].plot(x,y,color="red")
    
x = [x_+(w_-im_crop_r_start.shape[1]) for x_ in x]
y = [y_+(h_-im_crop_r_start.shape[0]) for y_ in y]

ax[1].imshow(im_crop_r,cmap="gray")
ax[1].plot(x,y,color="red")
ax[1].scatter(start_coords[1]+w_-im_crop_r_start.shape[1],start_coords[0], color="orange", alpha=0.4)
ax[1].scatter(end_coords[1]+w_-im_crop_r_start.shape[1],end_coords[0], color = "magenta", alpha = 0.4)


plt.show()


print("RUNNING WITH OLD")
A, T, x, y = shortest_path_old(im_crop_r_start,"horizontal", start_point= start_coords, end_point=end_coords)
x,y = backtrace_path(A,T,end_point=end_coords)
fig, ax = plt.subplots(1,2)
ax[0].matshow(A)
ax[0].plot(x,y,color="red")
    
x = [x_+(w_-im_crop_r_start.shape[1]) for x_ in x]
y = [y_+(h_-im_crop_r_start.shape[0]) for y_ in y]

ax[1].imshow(im_crop_r,cmap="gray")
ax[1].plot(x,y,color="red")
ax[1].scatter(start_coords[1]+w_-im_crop_r_start.shape[1],start_coords[0], color="orange", alpha=0.4)
ax[1].scatter(end_coords[1]+w_-im_crop_r_start.shape[1],end_coords[0], color = "magenta", alpha = 0.4)

plt.show()

print(A[end_coords[0],end_coords[1]])
print(A[end_coords[0],end_coords[1]]) #if this is larger than zero there is a defect present
plt.matshow(A,vmin=0.0,vmax=1) #the complete trace of electrical connectivity from point A




# #electrical connectivity between two points 
# im_crop_r_start[im_crop_r_start==1.0] = 1e6
# #im_crop_r[(im_crop_r>=0.60) & (im_crop_r<=0.71)] = 0.0 
# A, T, x, y = shortest_path_left_right(im_crop_r_start,"horizontal", start_point=start_coords, end_point=end_coords)
# #plot_results(im_crop_r_start,A,x,y)
# fig, ax = plt.subplots(1,2)
# ax[0].matshow(A)
# ax[0].plot(x,y,color="red")
    
# x = [x_+(w_-im_crop_r_start.shape[1]) for x_ in x]
# y = [y_+(h_-im_crop_r_start.shape[0]) for y_ in y]

# ax[1].imshow(im_crop_r,cmap="gray")
# ax[1].plot(x,y,color="red")
# ax[1].scatter(start_coords[1]+w_-im_crop_r_start.shape[1],start_coords[0], color="orange", alpha=0.4)
# ax[1].scatter(end_coords[1]+w_-im_crop_r_start.shape[1],end_coords[0], color = "magenta", alpha = 0.4)


# plt.show()
